local script = require 'scripttools'.scope 'hijack.lua'
script.usage "Script usage: %s <chromote name prefix> <wifi ssid>"

print(_VERSION)

local name, ssid = ...
script.expect(name, "Missing chromote name prefix")
script.expect(ssid, "Missing wifi ssid")

script.dofile = require 'scripttools'.dofile
script.dofile 'bootstrap.lua'
script.dofile ('chromote.lua', name)
script.dofile ('keepalive.lua', ssid)
