--[[
  Iterate through all the power schemes and
  turn off sleep and hibernate.
]]

local script = require 'logrun'.scope 'powercfg.lua'

-- Grab list of Power Scheme GUIDs
local guid_pattern = "[%l%d-]+-%x+"
local scheme_guids = io.popen "powercfg -l":read '*a':gmatch(guid_pattern)

-- subgroup guid -> setting guid -> setting index
local power_settings =
{
  -- password on wakeup (disable)
  ["fea3413e-7e05-4911-9a71-700331f1c294"] =
  {
    ["0e796bdb-100d-47d6-a2d5-f7d2daa51f51"] = 0,
  },

  -- subgroup HD
  ["0012ee47-9041-4b5d-9b77-535fba8b1442"] =
  {
    ["6738e2c4-e8a5-4a42-b16a-e040e769756e"] = 0,   -- Turn off HD timer
  },

  -- subgroup Sleep
  ["238c9fa8-0aad-41ed-83f4-97be242c8f20"] =
  {
    ["29f6c1db-86da-48c5-9fdb-f2b67b1f44da"] = 0,   -- Sleep after timeout
    ["94ac6d29-73ce-41a6-809f-6363ba21b47e"] = 0,   -- Allow hybrid sleep
    ["9d7815a6-7ee4-497e-8888-515a05f02364"] = 0,   -- Hibernate after
    ["bd3b718a-0680-4d9d-8ab2-e1d2b4ac806d"] = 1,   -- Allow wake timers
  },

  -- subgroup Power button and lid
  ["4f971e89-eebd-4455-a8de-9e59040e7347"] =
  {
    ["5ca83367-6e45-459f-a27b-476b1d01c936"] = 0,   -- Lid close
    ["7648efa3-dd9c-4e3e-b566-50f929386280"] = 4,   -- Power button
    ["96996bc0-ad50-47ec-923b-6f41874dd9eb"] = 4,   -- Sleep button
    ["a7066653-8d6c-40a8-910e-a1f54b84c7e5"] = 0,   -- Start menu power button
  },

  -- subgroup Display settings
  ["7516b95f-f776-4464-8c53-06167f40cc99"] =
  {
    ["17aaa29b-8b43-4b94-aafe-35f64daaf1ee"] = 0,   -- Dim display
    ["3c0bc021-c8a8-4e07-a973-6b14cbcb2b7e"] = 600, -- Turn off display
    ["aded5e82-b909-4619-9949-f5d71dac0bcb"] = 60,  -- Display brightness
    ["f1fbfde2-a960-4165-9f88-50667911ce96"] = 30,  -- Dimmed display brightness
  },
}

local powercfg = function(scheme, settings)
  local power_cmd = "powercfg -%s %s %s %s %d"
  for sub, setting_guids in pairs(settings) do
    for setting, value in pairs(setting_guids) do
      script.sh(power_cmd:format("setacvalueindex", scheme, sub, setting, value), script.continue_onerror)
      script.sh(power_cmd:format("setdcvalueindex", scheme, sub, setting, value), script.continue_onerror)
    end
  end
end

for scheme in scheme_guids do
  powercfg(scheme, power_settings)
end
