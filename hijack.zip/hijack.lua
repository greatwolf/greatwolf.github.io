local script = require 'logrun'.scope 'hijack.lua'
script.usage "Script usage: %s <chromote name prefix> <wifi ssid>"


local name, ssid = ...
script.expect(name, "Missing chromote name prefix")
script.expect(ssid, "Missing wifi ssid")

script.dofile = require 'logrun'.dofile
script.dofile 'bootstrap.lua'
script.dofile ('chromote.lua', name)
script.dofile ('keepalive.lua', ssid)
script.dofile 'powercfg.lua'
