--[[
  Create Task Schedule that:
    - Reconnects wifi every hour incase it's off
    - restart Chrome Remote Desktop service for refresh

  Script usage: KeepAlive.lua <ssid name>
]]

local taskxml =
[[<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.3" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <Triggers>
    <TimeTrigger>
      <Repetition>
        <Interval>PT2H</Interval>
        <StopAtDurationEnd>false</StopAtDurationEnd>
      </Repetition>
      <StartBoundary>2020-01-24T12:00:00</StartBoundary>
      <ExecutionTimeLimit>PT5M</ExecutionTimeLimit>
      <Enabled>true</Enabled>
    </TimeTrigger>
  </Triggers>
  <Principals>
    <Principal id="Author">
      <UserId>S-1-5-18</UserId>
      <RunLevel>HighestAvailable</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>Parallel</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <AllowHardTerminate>true</AllowHardTerminate>
    <StartWhenAvailable>false</StartWhenAvailable>
    <RunOnlyIfNetworkAvailable>false</RunOnlyIfNetworkAvailable>
    <IdleSettings>
      <StopOnIdleEnd>false</StopOnIdleEnd>
      <RestartOnIdle>false</RestartOnIdle>
    </IdleSettings>
    <AllowStartOnDemand>true</AllowStartOnDemand>
    <Enabled>true</Enabled>
    <Hidden>false</Hidden>
    <RunOnlyIfIdle>false</RunOnlyIfIdle>
    <DisallowStartOnRemoteAppSession>false</DisallowStartOnRemoteAppSession>
    <UseUnifiedSchedulingEngine>false</UseUnifiedSchedulingEngine>
    <WakeToRun>true</WakeToRun>
    <ExecutionTimeLimit>PT10M</ExecutionTimeLimit>
    <Priority>7</Priority>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>netsh</Command>
      <Arguments>wlan connect SSID="%s" name="%s"</Arguments>
    </Exec>
    <Exec>
      <Command>net</Command>
      <Arguments>stop chromoting</Arguments>
    </Exec>
    <Exec>
      <Command>net</Command>
      <Arguments>start chromoting</Arguments>
    </Exec>
  </Actions>
</Task>
]]


local script = require 'logrun'.scope 'keepalive.lua'
script.usage "Script usage: %s <ssid name>"

local keepalive_xml = "keepalive.xml"
local ssid = script.expect(..., "Expected ssid name")

-- create xml task file
local keepalive = script.assert( io.open(keepalive_xml, 'w+') )
keepalive:write( taskxml:format(ssid, ssid) )
keepalive:close()

-- import it into task scheduler
script.sh("schtasks /Delete /TN \"Keep Alive\" /F 2>NUL", script.ok_onerror)
script.sh("schtasks /Create /TN \"Keep Alive\" /XML " .. keepalive_xml)
script.sh("del " .. keepalive_xml)
