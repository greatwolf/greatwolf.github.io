--[[
  Install Chrome Remote Desktop and set up the online connection.
  The OAuth token must be setup ahead of time here:

    'https://remotedesktop.google.com/headless/'

  and then saving the token to 'crd_oauth.txt' in angelfire ftp.
]]

local http    = require 'socket.http'
local script  = require 'scripttools'.scope 'chromote.lua'
script.usage "Script usage: %s <chromote name prefix>"

function fetch_oauth(url)
  local oauth_token = script.assert (http.request(url),
                                     "could not get oauth token from " .. url .. ".")
  oauth_token = oauth_token:match('4/[%w-_]+')
  -- Google's OAuth token starts with '4/' followed by 87 [alphanumeric, _, -] characters
  assert(oauth_token and #oauth_token == 89, "got an invalid oauth token.")
  return oauth_token
end

-- Chromote setup parameters
local name = script.expect(..., "Expected name prefix")

local version = '80.0.3987.18'
local pin     = 123456
local oauth_url = 'http://angelfire.com/theforce/greatwolf/crd_oauth.txt'
local cpu_model = io.popen "wmic cpu get name"
                    :read '*a'
                    :match "Name%s+(.+)"    -- capture cpu model
                    :gsub("AMD%s+", '')     -- strip out 'AMD'
                    :gsub("Intel%(R%) Core%(TM%)%w*%s+", '')  -- strip out Intel
                    :gsub("CPU", '')        -- strip 'CPU'
                    :gsub("@.+", '')        -- strip out everything after '@'
                    :gsub('%s+$', '')       -- trim trailing whitespace
                    :gsub('%s+', '', 1)     -- usually cpu model is in first 2 words
                    :gsub('%s+', '-', 1)
                    :gsub('%s.+', '')       -- whatever's left are probably extra, strip it out

local chromote_path = os.getenv 'PROGRAMFILES(X86)'
local oauth_token   = fetch_oauth(oauth_url)

-- Install Chromote
script.sh "chromeremotedesktophost.msi"

-- Setup Chromote connection
local chromote_cmd =
  ([["%s\Google\Chrome Remote Desktop\%s\remoting_start_host.exe" --code=%s --redirect-url=https://remotedesktop.google.com/_/oauthredirect --name=%s --pin=%d]])

chromote_cmd = chromote_cmd:format(chromote_path, version, oauth_token, name .. cpu_model, pin)
script.sh(chromote_cmd, script.continue_onerror)
