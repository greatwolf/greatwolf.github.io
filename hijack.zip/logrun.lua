local logrun =
{
  dofile = function(src, ...)
    loadfile(src)(...)
    collectgarbage 'collect'
  end,
  scope = function(luafile)
    local runok = true
    local usage
    local assert_softfail = function(cond, msg, showusage)
      if cond then return cond end
      
      print(msg or debug.traceback(nil, 2))
      if showusage and usage then print( usage:format(luafile) ) end
      runok = false
    end
    local assert_fail =  function(cond, msg, showusage)
      return  assert_softfail(cond, msg, showusage)
          or  os.exit(false, true)
    end

    local scopeobj =
    {
      assert = function(cond, msg) return assert_fail(cond, msg) end,
      expect = function(cond, msg) return assert_fail(cond, msg, true) end,
      usage = function(usage_msg)
        assert(type(usage_msg) == 'string', "string expected for usage message")
        usage = usage_msg:format(luafile)
      end,
      sh  = function(cmd, error_policy)
        local status = select( 3, os.execute(cmd) )
        if status ~= 0 then print(cmd) end
        if not error_policy then
          assert_fail(status == 0)
        elseif error_policy == 1 then
          assert_softfail(status == 0)
        end
      end,
      continue_onerror  = 1,  -- continue and set error flag
      ok_onerror        = 2,  -- continue but don't set error flag
    }
    local scope_mt =
    {
      __gc = function()
        print(luafile, runok and "ok." or "failed.")
      end
    }
    return setmetatable(scopeobj, scope_mt)
  end,
}

return logrun
