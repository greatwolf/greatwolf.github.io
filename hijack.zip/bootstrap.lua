--[[
  Copies Lua VM and modules to HOMEDRIVE(usually C:)
  and associate .lua in registry.
  Allows running lua scripts by just typing script filename.
]]

local winreg = require 'winreg'
local script = require 'scripttools'.scope 'bootstrap.lua'

function dir_exist(dirname)
  local cmd = "type %s 2>&1"
  return nil == io.popen( cmd:format(dirname) ):read '*a':match 'system cannot find the'
end

local drive     = os.getenv "HOMEDRIVE"
local lua_dir   = io.popen "dir/b Lua*":read '*l' or error "Missing Lua Component in hijack."
local lua_base  = lua_dir:gsub('%-(%d)%.(%d).%d$', '%1%2')
local target_dir  = drive .. '\\' .. lua_dir


-- HOMEDRIVE on machine should not have this lua directory.
if dir_exist(target_dir) then
  script.sh("rmdir /S /Q " .. target_dir)
end
-- script.assert(not dir_exist(target_dir), "Destination already exist: " .. target_dir)

-- copy Lua + modules to main drive
local copy_cmd = "xcopy /V /I /S %s %s"
script.sh( copy_cmd:format(lua_dir, target_dir) )

-- set .lua file association
local lua_cmd = ([[%s\lua\%s.exe "%%1" %%*]]):format(target_dir, lua_base)

local extkey    = winreg.createkey[[HKCR\.lua]]
local shcmdkey  = winreg.createkey( ([[HKCR\%s\Shell\Open\Command]]):format(lua_base) )
extkey:setvalue   (nil, lua_base)
shcmdkey:setvalue (nil, lua_cmd)
